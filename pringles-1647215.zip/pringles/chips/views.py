from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render_to_response
from django.views.decorators.csrf import csrf_exempt
from chips.models import chips1
import matplotlib.pyplot as plt
import numpy as np

# Create your views here.

@csrf_exempt
def index(request):
	return render_to_response('index.html')

@csrf_exempt
def save(request):
	t=request.GET['t']
	s=request.GET['s']
	c=chips1()
	c.t=t
	c.s=s
	c.save()
	return render_to_response('save.html')
            
@csrf_exempt
def save(request):
  a=float(request.POST['a'])
  u=float(request.POST['u'])
  t=10;
  slist=[]
  tlist=[]
  s=0
  obj=Values()
  while t<30:
    s=(u*t)+(0.5*a*t*t)
    obj.s=s
    obj.t=t
    obj.save()
    slist.append(s)
    tlist.append(t)
    t+=2
  plt.plot(slist,tlist)
  plt.show()
  return render_to_response("index.html");